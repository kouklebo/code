create definer = root@localhost trigger updateBeerAvgRating
    after insert
    on rating
    for each row
    UPDATE data_beers
    SET rating = (SELECT AVG(rating) FROM rating R WHERE R.Beer_id = NEW.Beer_id)
    WHERE id = NEW.Beer_id;

