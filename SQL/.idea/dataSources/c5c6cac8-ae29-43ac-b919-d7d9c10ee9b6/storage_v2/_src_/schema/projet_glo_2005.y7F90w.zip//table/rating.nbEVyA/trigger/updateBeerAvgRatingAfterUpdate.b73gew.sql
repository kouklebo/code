create definer = root@localhost trigger updateBeerAvgRatingAfterUpdate
    after update
    on rating
    for each row
    UPDATE data_beers
    SET rating = (select AVG(rating) FROM rating R WHERE R.Beer_id = NEW.Beer_id)
    WHERE id = NEW.Beer_id;

